<script>

//Define secure user functions here


</script>
