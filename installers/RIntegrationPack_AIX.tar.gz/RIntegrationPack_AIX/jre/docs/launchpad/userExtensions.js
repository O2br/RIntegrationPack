<script>

var userSecurityCheck = new Function('return window');

//Define user functions below


</script>
