#!/bin/sh
# Licensed Materials - Property of IBM
# 5648-F10 (C) Copyright International Business Machines Corp. 2007
# All Rights Reserved
# US Government Users Restricted Rights - Use, duplication or disclosure
# restricted by GSA ADP Schedule Contract with IBM Corp.

CLASSPATH=.:lib/bin.jar:lib/AZX_engine.jar:lib/AZC_ExpressLogger.jar; export CLASSPATH
