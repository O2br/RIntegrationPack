#!/bin/ksh

main(){
	cmdArgCheck "$@"
	launchApp
}

#Process command-line arguments
cmdArgCheck()
{	
	JVMARGS=""
	
	INSTALL_OS=`uname -s`
	
	while [ $# -gt 0 ] 
	do
		case "$1" in
		--) 
			shift; 
			break;;
		-help) 
			argHelp;;
		-console) 
			getTerminalWidth
			MODE=1;;
		-silent) 			
			MODE=2;;
		-options) 
			OPTIONS_FILE=$2; 
			validateOptionsFile; shift;;						
		*)
			echo "$1: invalid option"
			terminateWithError 1 ;;
	    esac
	    shift	 
	done
}

argHelp(){
cat <<EOF
Usage:
	$PROGRAM [ --? ]
		 [ -help ]                       : print help
		 [ -console ]                    : run in console mode
EOF
exit 0
}


#Validate options file provided is valid and readable
validateOptionsFile(){
	if [ ! -f "$OPTIONS_FILE" ] || [ ! -r "$OPTIONS_FILE" ] ; then
		writeToLog "The options file specified is not found or is invalid."
		terminateWithError 2
	fi
}

#Get the width of the current terminal (only for Console mode)
getTerminalWidth(){		
        case "$INSTALL_OS" in
        Linux | HP-UX | AIX)
                TERM_WIDTH=`stty size | awk '{ print $2 }'`
                ;;
        SunOS)
                TERM_WIDTH=`stty | grep rows | awk '{ print $6 }' | awk -F\; '{ print $1 }'`
                ;;
        esac
}


#Launch application
launchApp(){

	SETUP_PATH=`dirname $0`

	# Set Java system variables based on command-line options	
	[ -z "$MODE" ] && MODE=0
	JVMARGS="$JVMARGS -DinstallMode=$MODE"
	
	# Pass the terminal width
	[ -z "$TERM_WIDTH" ] && TERM_WIDTH=0
	JVMARGS="$JVMARGS -DtermWidth=$TERM_WIDTH"
	
	# Pass the setup path
	JVMARGS="$JVMARGS -Dsetup.home=$SETUP_PATH"
	
	# Pass the options file
	[ -n "$OPTIONS_FILE" ] && JVMARGS="$JVMARGS -Doptions=$OPTIONS_FILE"	
	
	# Classpath
	JVMARGS="$JVMARGS -classpath $SETUP_PATH/setup.jar"
	
	if [ "$INSTALL_OS" = "AIX" ] ; then
		JAVA_EXEC="$SETUP_PATH/jre/jre/bin/java"
	else
		JAVA_EXEC="$SETUP_PATH/jre/bin/java"
	fi
	
	exec $JAVA_EXEC $JVMARGS com.microstrategy.install.Controller
}

main "$@"
